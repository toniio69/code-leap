import { LoginPage3 } from "@/components/login-page-1"
import { socialButtons } from "./data"

export default function Page() {
  return (
    <div className="flex min-h-svh w-full items-center justify-center">
      <div className="w-full">
        <LoginPage3 socialButtons={socialButtons} />
      </div>
    </div>
  )
}
